from serial import Serial
import struct
import numpy as np
import matplotlib.pyplot as plt
import time

### 取得生醫訊號
w=0
read=0
first=0
count=0
data_len=0
ser_arc = Serial('COM7',115200,bytesize=8)

ekg_fil=[]
ekg_org=[]
ppg_fil=[]
ppg_org=[]

start_time=time.time()
print(start_time)

while (1):
    data_len += 1
    if time.time()-start_time>1:
        # print(count)
        start_time=time.time()
        count=0
    data_raw = ser_arc.read(size=1)
    # print(data_raw)
    if data_raw==b'c':
        check_byte = ser_arc.read(size=1)
        # print(struct.unpack("B",data_raw)[0])
        data_raw = ser_arc.read(size=4)
        for i in range(1):
            ba = bytearray()
            ba.append(data_raw[i*3+3])
            ba.append(data_raw[i*3+2])
            ba.append(data_raw[i*3+1])
            ba.append(data_raw[i*3+0])
            ekg_org.append(int(struct.unpack("!f",ba)[0]))
            print('ekg_org : ', struct.unpack("!f",ba)[0])
        data_raw = ser_arc.read(size=4)
        
        for i in range(1):
            ba = bytearray()
            ba.append(data_raw[i*3+3])
            ba.append(data_raw[i*3+2])
            ba.append(data_raw[i*3+1])
            ba.append(data_raw[i*3+0])
            ppg_org.append(int(struct.unpack("!f",ba)[0]))
            print('ppg_org : ', struct.unpack("!f",ba)[0])
        count=count+1
    if len(ekg_org)>=2000 and len(ppg_org)>=2000:
        break

'''
Save ECG and PPG signal,
'''
### 儲存檔案
path = './data/ECG.txt'
f = open(path, 'w')
for data in ekg_org:
    print(data, file=f)
f.close()

path = './data/PPG.txt'
f = open(path, 'w')
for data in ppg_org:
    print(data, file=f)
f.close()

'''
Plot ECG and PPG signal,
Use ECG or PPG sigffffnal calculate Pulse Rate
'''
ecg_y = ekg_org
ppg_y = ppg_org

### Find R Peak
ecg_px = []
ecg_py = []
threshold = 261650
for i in range(len(ecg_y)):
    if (i == 0) or (i == len(ecg_y) - 1):
        pass
    elif (ecg_y[i] >= threshold) and (ecg_y[i] > ecg_y[i-1]) and (ecg_y[i] > ecg_y[i+1]):
        ecg_px.append(i)
        ecg_py.append(ecg_y[i])
RR_interval = np.subtract(ecg_px[1:], ecg_px[:len(ecg_px)-1]) # 心跳間隔多少採樣

### Calculate Heart Rate
fs = 400 # 取樣頻率
heart_rate = 60 * fs / RR_interval # 心律
heart_rate = [round(i, 2) for i in heart_rate] # 取小數點 2 位數
print(f'Heart Rate: {heart_rate} /min')
print(f'Average Heart Rate: {np.mean(heart_rate)} /min')

### PLOT
fig, ax = plt.subplots(2,1)
ax[0].plot(ecg_y)
ax[0].plot(ecg_px, ecg_py, 'ro')
ax[1].plot(ppg_y)
plt.show()
