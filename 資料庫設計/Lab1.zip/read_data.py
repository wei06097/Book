import numpy as np
import matplotlib.pyplot as plt

### Read ECG & PPG
ecg_y = []
with open('./data/ECG.txt') as f:
    while True:
        line = f.readline()
        if not line:
            break
        ecg_y.append(int(line))

ppg_y = []
with open('./data/PPG.txt') as f:
    while True:
        line = f.readline()
        if not line:
            break
        ppg_y.append(int(line))

### Find R Peak
ecg_px = []
ecg_py = []
threshold = 261650
for i in range(len(ecg_y)):
    if (i == 0) or (i == len(ecg_y) - 1):
        pass
    elif (ecg_y[i] >= threshold) and (ecg_y[i] > ecg_y[i-1]) and (ecg_y[i] > ecg_y[i+1]):
        ecg_px.append(i)
        ecg_py.append(ecg_y[i])
RR_interval = np.subtract(ecg_px[1:], ecg_px[:len(ecg_px)-1]) # 心跳間隔多少採樣

### Calculate Heart Rate
fs = 400 # 取樣頻率
heart_rate = 60 * fs / RR_interval # 心律
heart_rate = [round(i, 2) for i in heart_rate] # 取小數點 2 位數
print(f'Heart Rate: {heart_rate} /min')
print(f'Average Heart Rate: {np.mean(heart_rate)} /min')

### PLOT
fig, ax = plt.subplots(2,1)
ax[0].plot(ecg_y)
ax[0].plot(ecg_px, ecg_py, 'ro')
ax[1].plot(ppg_y)
plt.show()
